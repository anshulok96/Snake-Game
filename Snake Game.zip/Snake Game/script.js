/* =========================================================
   NEON SNAKE — JavaScript
   Requirements:
   ✅ Lose if hits edge OR itself
   ✅ Separate state data structure + pseudocode (included above)
   ✅ Comments for learning + presentation
   ========================================================= */

/* ---------------------------
   1) CANVAS SETUP
---------------------------- */
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

/* UI elements */
const scoreText = document.getElementById("scoreText");
const bestText = document.getElementById("bestText");
const speedText = document.getElementById("speedText");
const messageEl = document.getElementById("message");

const startBtn = document.getElementById("startBtn");
const pauseBtn = document.getElementById("pauseBtn");
const restartBtn = document.getElementById("restartBtn");

const overlayEl = document.getElementById("overlay");
const modalTitleEl = document.getElementById("modalTitle");
const modalTextEl = document.getElementById("modalText");
const playAgainBtn = document.getElementById("playAgainBtn");

/* Mobile buttons */
const mobileBtns = [...document.querySelectorAll(".m-btn")];

/* ---------------------------
   2) INITIAL STATE (DATA STRUCTURE)
   This is exactly what you can submit for the assignment.
---------------------------- */
const initialState = {
  board: {
    cols: 20,
    rows: 20,
    cellSize: 22
  },
  snake: {
    body: [{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }],
    dir: { x: 1, y: 0 },      // moving right
    nextDir: { x: 1, y: 0 }   // buffered direction
  },
  food: { x: 14, y: 10 },
  score: 0,
  bestScore: 0,
  speedMs: 500,  // initial speed (ms per tick)
  isRunning: false,
  isGameOver: false
};

/* We will copy initialState into a mutable state object */
let state = {};
let loopTimer = null;

/* ---------------------------
   3) HELPERS
---------------------------- */

/* Deep-ish clone for our simple nested objects */
function cloneState(obj) {
  return JSON.parse(JSON.stringify(obj));
}

/* Random integer (0..max-1) */
function randInt(max) {
  return Math.floor(Math.random() * max);
}

/* Check if two cells are the same position */
function sameCell(a, b) {
  return a.x === b.x && a.y === b.y;
}

/* Check if a cell is inside the board */
function inBounds(cell) {
  return (
    cell.x >= 0 &&
    cell.x < state.board.cols &&
    cell.y >= 0 &&
    cell.y < state.board.rows
  );
}

/* Place food on an empty cell (not on the snake) */
function placeFood() {
  while (true) {
    const cell = {
      x: randInt(state.board.cols),
      y: randInt(state.board.rows)
    };

    const onSnake = state.snake.body.some(seg => sameCell(seg, cell));
    if (!onSnake) {
      state.food = cell;
      return;
    }
  }
}

/* ---------------------------
   4) RENDERING (DRAW)
---------------------------- */
function draw() {
  const { cols, rows, cellSize } = state.board;

  // Clear full canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw grid background
  // (small lines make it look “game-like”)
  ctx.save();
  ctx.globalAlpha = 0.25;
  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  for (let x = 0; x <= cols; x++) {
    ctx.beginPath();
    ctx.moveTo(x * cellSize, 0);
    ctx.lineTo(x * cellSize, rows * cellSize);
    ctx.stroke();
  }
  for (let y = 0; y <= rows; y++) {
    ctx.beginPath();
    ctx.moveTo(0, y * cellSize);
    ctx.lineTo(cols * cellSize, y * cellSize);
    ctx.stroke();
  }
  ctx.restore();

  // Draw food (glowing circle)
  drawFood();

  // Draw snake
  drawSnake();
}

/* Draw the snake segments */
function drawSnake() {
  const { cellSize } = state.board;

  state.snake.body.forEach((seg, index) => {
    const x = seg.x * cellSize;
    const y = seg.y * cellSize;

    // Head is brighter
    if (index === 0) {
      ctx.fillStyle = "rgba(68,255,153,0.65)";
      ctx.shadowColor = "rgba(68,255,153,0.6)";
      ctx.shadowBlur = 14;
    } else {
      ctx.fillStyle = "rgba(45,226,230,0.35)";
      ctx.shadowColor = "rgba(45,226,230,0.3)";
      ctx.shadowBlur = 10;
    }

    roundRectFill(x + 3, y + 3, cellSize - 6, cellSize - 6, 8);
    ctx.shadowBlur = 0;
  });
}

/* Draw the food */
function drawFood() {
  const { cellSize } = state.board;
  const x = state.food.x * cellSize + cellSize / 2;
  const y = state.food.y * cellSize + cellSize / 2;

  ctx.save();
  ctx.fillStyle = "rgba(255,77,109,0.75)";
  ctx.shadowColor = "rgba(255,77,109,0.65)";
  ctx.shadowBlur = 16;

  ctx.beginPath();
  ctx.arc(x, y, cellSize * 0.28, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/* Helper to draw rounded rectangles */
function roundRectFill(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
  ctx.fill();
}

/* ---------------------------
   5) GAME LOOP (TICK)
---------------------------- */
function tick() {
  if (!state.isRunning || state.isGameOver) return;

  // Apply buffered direction
  state.snake.dir = { ...state.snake.nextDir };

  const head = state.snake.body[0];

  // Next head position
  const newHead = {
    x: head.x + state.snake.dir.x,
    y: head.y + state.snake.dir.y
  };

  /* 1) EDGE COLLISION -> LOSE */
  if (!inBounds(newHead)) {
    gameOver("You hit the wall!");
    return;
  }

  /* 2) SELF COLLISION -> LOSE
     We check if the new head hits any existing segment.
     Note: if you want to allow moving into the last tail cell
     when not growing, you'd handle that specially; this simple
     version is still correct for most Snake games.
  */
  const hitsSelf = state.snake.body.some(seg => sameCell(seg, newHead));
  if (hitsSelf) {
    gameOver("You hit yourself!");
    return;
  }

  // Add new head
  state.snake.body.unshift(newHead);

  // FOOD EAT check
  if (sameCell(newHead, state.food)) {
    state.score++;

    // Speed up slowly (higher score => faster)
    if (state.speedMs > 70) state.speedMs -= 3;

    placeFood();
    updateHUD();

    // Restart timer with new speed
    restartLoopTimer();
  } else {
    // Normal move => remove tail
    state.snake.body.pop();
  }

  draw();
}

/* Restart the interval timer when speed changes */
function restartLoopTimer() {
  if (loopTimer) clearInterval(loopTimer);
  loopTimer = setInterval(tick, state.speedMs);
}

/* ---------------------------
   6) INPUT (KEYS + MOBILE)
---------------------------- */

/* Prevent reversing direction directly (snake can't go left if moving right) */
function setDirection(dx, dy) {
  const cur = state.snake.dir;

  // Prevent 180-degree turn
  if (cur.x === -dx && cur.y === -dy) return;

  state.snake.nextDir = { x: dx, y: dy };
}

/* Keyboard controls */
document.addEventListener("keydown", (e) => {
  const k = e.key.toLowerCase();

  if (k === "arrowup" || k === "w") setDirection(0, -1);
  if (k === "arrowdown" || k === "s") setDirection(0, 1);
  if (k === "arrowleft" || k === "a") setDirection(-1, 0);
  if (k === "arrowright" || k === "d") setDirection(1, 0);

  if (k === " ") togglePause(); // space to pause/resume
});

/* Mobile buttons */
mobileBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    const dir = btn.dataset.dir;
    if (dir === "up") setDirection(0, -1);
    if (dir === "down") setDirection(0, 1);
    if (dir === "left") setDirection(-1, 0);
    if (dir === "right") setDirection(1, 0);
  });
});

/* ---------------------------
   7) UI + GAME CONTROL
---------------------------- */
function updateHUD() {
  scoreText.textContent = state.score;
  bestText.textContent = state.bestScore;
  speedText.textContent = `${state.speedMs}ms`;
}

/* Start */
function start() {
  if (state.isGameOver) return;

  state.isRunning = true;
  messageEl.textContent = "Running... (Space = Pause)";
  restartLoopTimer();
}

/* Pause/Resume */
function togglePause() {
  if (state.isGameOver) return;

  state.isRunning = !state.isRunning;
  messageEl.textContent = state.isRunning ? "Running... (Space = Pause)" : "Paused. Press Start to resume.";
}

/* Full reset */
function resetGame() {
  // keep best score across resets
  const best = state.bestScore || 0;

  state = cloneState(initialState);
  state.bestScore = best;

  placeFood();
  updateHUD();

  // stop timers
  if (loopTimer) clearInterval(loopTimer);
  loopTimer = null;

  hideModal();

  // draw initial state
  draw();

  messageEl.textContent = "Press Start to play. Avoid walls and yourself!";
}

/* Game Over handler */
function gameOver(reason) {
  state.isGameOver = true;
  state.isRunning = false;

  if (loopTimer) clearInterval(loopTimer);
  loopTimer = null;

  // Update best score
  if (state.score > state.bestScore) state.bestScore = state.score;

  updateHUD();

  showModal("Game Over 💥", `${reason} Your score: <b>${state.score}</b>.`);
}

/* Modal helpers */
function showModal(title, htmlText) {
  modalTitleEl.textContent = title;
  modalTextEl.innerHTML = htmlText;
  overlayEl.classList.remove("hidden");
}
function hideModal() {
  overlayEl.classList.add("hidden");
}

/* ---------------------------
   8) BUTTON EVENTS
---------------------------- */
startBtn.addEventListener("click", start);
pauseBtn.addEventListener("click", togglePause);
restartBtn.addEventListener("click", resetGame);
playAgainBtn.addEventListener("click", () => { resetGame(); start(); });

overlayEl.addEventListener("click", (e) => {
  if (e.target === overlayEl) hideModal();
});

/* ---------------------------
   9) INIT (IMPORTANT)
   - Set canvas size based on board config
---------------------------- */
function init() {
  state = cloneState(initialState);

  // Set canvas pixel size to match grid (important for crisp drawing)
  canvas.width = state.board.cols * state.board.cellSize;
  canvas.height = state.board.rows * state.board.cellSize;

  resetGame();
}

init();
